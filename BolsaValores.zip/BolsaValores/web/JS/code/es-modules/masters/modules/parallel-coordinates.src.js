/**
 * @license  @product.name@ JS v@product.version@ (@product.date@)
 *
 * Support for parallel coordinates in Highcharts
 *
 * (c) 2010-2017 Pawel Fus
 *
 * License: www.highcharts.com/license
 */
'use strict';
import '../../modules/parallel-coordinates.src.js';
